"""
Vòng lặp tiến hoá chính của NSGA-II cải tiến.
"""

from __future__ import annotations

from typing import Callable, List, Optional

import numpy as np

from .core import CreationMode, Individual, ProblemWrapper
from .operators import (
    _make_evaluated_individual,
    de_mutation,
    generate_obl_offspring,
    get_neighborhood_indices,
    initialize_from_data,
    initialize_obl,
    sbx_crossover_mutation,
    tournament_selection,
)
from .selection import environmental_selection, remove_duplicates


class OADE_NSGAII:
    """
    NSGA-II cải tiến với DE thích nghi, OBL và partial restart khi trì trệ.

    Cải tiến so với NSGA-II gốc (Deb et al., 2002)
    ------------------------------------------------
    - Khởi tạo OBL + Sobol/LHS khi initial_x=None; benchmark dùng uniform chung
    - Đột biến DE/current-to-pbest/1 hướng láng giềng thay SBX đơn thuần
    - F cập nhật theo Lehmer mean, CR theo trung bình cộng của DE có rank 1
    - Phun đa dạng định kỳ qua OBL mỗi 10 thế hệ
    - Phát hiện trì trệ và partial restart khi ideal point ngừng cải thiện

    Benchmark truyền initial_x để giữ cùng quần thể ban đầu giữa các solver,
    nên không đo lợi ích của khởi tạo Sobol/OBL. OBL định kỳ trong quá trình
    tiến hoá vẫn hoạt động khi enable_obl=True, độc lập với cách khởi tạo.
    """

    def __init__(self, problem: ProblemWrapper, pop_size: int = 100, n_gen: int = 100) -> None:
        self.problem  = problem
        self.pop_size = pop_size
        self.n_gen    = n_gen
        self.n_var    = problem.n_var
        self.n_obj    = problem.n_obj
        self.xl       = problem.xl
        self.xu       = problem.xu

        # Tham số DE thích nghi — khởi đầu tại điểm trung tính
        self.mean_F  = 0.5  # trung bình phân phối Cauchy của scale factor F
        self.mean_CR = 0.5  # trung bình phân phối Normal của crossover rate CR
        self.prob_de = 0.5  # xác suất chọn DE thay vì SBX
        self.probability_update_mode = "success_rate"  # or fixed
        self.last_probability_update = {}
        self.initialization_seed = None  # explicit Sobol/OBL reproducibility

        # Bài toán nhiều mục tiêu cần láng giềng rộng hơn để ước lượng tốt
        min_neighbors = 10 if self.n_obj >= 3 else 5
        self.n_neighbors = max(min_neighbors, int(pop_size * 0.15))

        # Tham số SBX và Polynomial Mutation
        self.pc    = 0.9                                           # xác suất lai ghép
        self.pm    = 1.0 / (self.n_var * np.log(max(pop_size, 2)))  # xác suất đột biến mỗi gene
        self.eta_c = 20.0
        self.eta_m = 20.0

        # Ngưỡng phát hiện trì trệ và chế độ restart
        self.stagnation_patience   = n_gen // 4  # số thế hệ không cải thiện trước khi restart
        self.stagnation_tolerance  = 1e-4        # cải thiện nhỏ hơn ngưỡng này bị coi là trì trệ
        self.restart_elite_ratio   = 0.8         # tỉ lệ cá thể tốt giữ lại sau restart (conservative)
        self.restart_mode          = "adaptive"  # mặc định: adaptive diversity-aware restart
        self.diversity_threshold   = 0.02        # ngưỡng sụp đổ đa dạng cho restart mới

        # Independent ablation switches; all enabled is the full OADE method.
        self.enable_fcr_adaptation = True
        self.enable_probability_adaptation = True
        self.enable_neighborhood = True
        self.enable_restart = True
        self.enable_obl = True

        # Trạng thái runtime
        self.population: List[Individual] = []
        self.history:    List[np.ndarray] = []  # lịch sử F mỗi thế hệ

    # Vòng lặp chính
    def run(
        self,
        initial_x: Optional[np.ndarray] = None,
        progress_callback: Optional[Callable[[int, int], None]] = None,
    ) -> np.ndarray:
        """
        Chạy thuật toán và trả về ma trận F của quần thể cuối, shape (pop_size, n_obj).
        Nếu initial_x được cung cấp, dùng nó làm quần thể khởi đầu (warm-start),
        bỏ qua hoàn toàn Sobol/OBL khởi tạo. Đây là chế độ benchmark uniform chung.
        Nếu không, khởi tạo bằng OBL + Sobol.
        """
        if self.probability_update_mode not in {"success_rate", "fixed"}:
            raise ValueError("probability_update_mode must be success_rate or fixed")
        self.population = self._build_initial_population(initial_x)
        self.history.clear()

        last_ideal         = None
        stagnation_counter = 0

        for gen in range(self.n_gen):
            stagnation_counter, last_ideal = self._check_and_handle_stagnation(
                stagnation_counter, last_ideal
            )

            offspring = self._generate_offspring(gen)
            self._evaluate_unevaluated(offspring)

            adaptation_pool = self.population + offspring
            combined        = remove_duplicates(adaptation_pool)
            combined        = self._fill_if_too_small(combined)
            self.population = environmental_selection(combined, self.pop_size, self.n_obj)

            self._update_adaptive_parameters(offspring, reference_population=adaptation_pool)
            self.history.append(np.array([ind.F for ind in self.population]))

            if progress_callback is not None:
                progress_callback(gen + 1, self.n_gen)

        return np.array([ind.F for ind in self.population])

    # Khởi tạo
    def _build_initial_population(self, initial_x: Optional[np.ndarray]) -> List[Individual]:
        """Khởi tạo từ dữ liệu có sẵn hoặc bằng OBL + Sobol nếu không có dữ liệu."""
        if initial_x is not None:
            pop = initialize_from_data(self.problem, initial_x)
            return environmental_selection(pop, self.pop_size, self.n_obj)
        return initialize_obl(self.problem, self.pop_size, seed=self.initialization_seed)

    # Sinh con lai
    def _generate_offspring(self, gen: int) -> List[Individual]:
        """Sinh toàn bộ con lai cho thế hệ này: DE hoặc SBX theo prob_de, thêm OBL mỗi 10 thế hệ."""
        neighbor_count = self.n_neighbors if self.enable_neighborhood else self.pop_size
        neighbor_indices = get_neighborhood_indices(self.population, neighbor_count)

        offspring = [
            self._create_one_child(i, neighbor_indices)
            for i in range(self.pop_size)
        ]

        offspring += self._generate_periodic_obl(gen)

        return offspring

    def _generate_periodic_obl(self, gen: int) -> List[Individual]:
        """Periodic injection only; independent of initialization and restart."""
        if self.enable_obl and gen % 10 == 0:
            return generate_obl_offspring(self.population, self.problem, self.xl, self.xu)
        return []

    def _create_one_child(self, idx: int, neighbor_indices: np.ndarray) -> Individual:
        """Tạo một con lai bằng DE (theo prob_de) hoặc SBX."""
        if np.random.rand() < self.prob_de:
            return de_mutation(
                idx, self.population, neighbor_indices,
                self.xl, self.xu, self.n_var, self.mean_F, self.mean_CR,
            )
        return sbx_crossover_mutation(
            tournament_selection(self.population),
            tournament_selection(self.population),
            self.xl, self.xu, self.n_var, self.pc, self.pm, self.eta_c, self.eta_m,
        )

    def _evaluate_unevaluated(self, offspring: List[Individual]) -> None:
        """Đánh giá batch tất cả con lai chưa có F. OBL offspring đã được đánh giá trước."""
        unevaluated = [ind for ind in offspring if ind.F is None]
        if not unevaluated:
            return

        x_batch = np.array([ind.X for ind in unevaluated])
        f_batch = self.problem.evaluate(x_batch)
        for ind, f in zip(unevaluated, f_batch):
            ind.F = f.flatten().copy()

    # Trì trệ và partial restart
    def _check_and_handle_stagnation(
        self, stagnation_counter: int, last_ideal: Optional[np.ndarray]
    ) -> tuple[int, np.ndarray]:
        """Đếm thế hệ trì trệ; restart khi đủ kiên nhẫn. Trả về (counter, ideal_point) mới."""
        current_ideal = np.min([ind.F for ind in self.population], axis=0)

        if last_ideal is not None:
            improved       = np.linalg.norm(current_ideal - last_ideal) >= self.stagnation_tolerance
            stagnation_counter = 0 if improved else stagnation_counter + 1

        if self.enable_restart and stagnation_counter >= self.stagnation_patience:
            if self.restart_mode == "adaptive":
                if self._is_diversity_collapsed():
                    self._adaptive_restart()
                    stagnation_counter = 0
                else:
                    stagnation_counter = self.stagnation_patience // 2
            else:
                self._partial_restart()
                stagnation_counter = 0

        return stagnation_counter, current_ideal

    def _is_diversity_collapsed(self) -> bool:
        """Kiểm tra xem quần thể có thực sự bị sụp đổ đa dạng không."""
        if len(self.population) < 2:
            return True
        f_mat = np.array([ind.F for ind in self.population])
        f_min = np.min(f_mat, axis=0)
        f_max = np.max(f_mat, axis=0)
        if float(np.max(f_max - f_min)) < 1e-3:
            return True

        x_mat = np.array([ind.X for ind in self.population])
        span = np.where((self.xu - self.xl) > 1e-12, self.xu - self.xl, 1.0)
        norm_x = (x_mat - self.xl) / span
        max_dim_std = float(np.max(np.std(norm_x, axis=0)))
        return max_dim_std < self.diversity_threshold

    def _adaptive_restart(self) -> None:
        """
        Conservative adaptive restart: giữ lại đa số cá thể ưu tú (80%),
        chỉ làm mới phần còn lại bằng đột biến OBL/Gauss quanh elite,
        bảo toàn tham số thích nghi DE.
        """
        n_keep = max(int(self.pop_size * self.restart_elite_ratio), int(self.pop_size * 0.8))
        elite = self.population[:n_keep]
        n_new = self.pop_size - len(elite)
        if n_new <= 0:
            return

        x_elite = np.array([ind.X for ind in elite])
        new_xs = []
        for _ in range(n_new):
            base = x_elite[np.random.randint(len(x_elite))]
            if np.random.rand() < 0.5:
                cand = self.xl + self.xu - base + np.random.normal(0, 0.05, self.n_var) * (self.xu - self.xl)
            else:
                cand = base + np.random.normal(0, 0.1, self.n_var) * (self.xu - self.xl)
            cand = np.clip(cand, self.xl, self.xu)
            new_xs.append(cand)

        x_new = np.array(new_xs)
        f_new = self.problem.evaluate(x_new)
        new_inds = [_make_evaluated_individual(x_new[i], f_new[i]) for i in range(n_new)]

        self.population = environmental_selection(elite + new_inds, self.pop_size, self.n_obj)
        self.mean_F = 0.8 * self.mean_F + 0.2 * 0.5
        self.mean_CR = 0.8 * self.mean_CR + 0.2 * 0.5

    def _partial_restart(self) -> None:
        """Giữ lại elite, thay thế phần còn lại bằng cá thể ngẫu nhiên, reset tham số DE."""
        n_keep   = int(self.pop_size * self.restart_elite_ratio)
        elite    = self.population[:n_keep]

        n_new    = self.pop_size - n_keep
        x_new    = self.xl + np.random.rand(n_new, self.n_var) * (self.xu - self.xl)
        f_new    = self.problem.evaluate(x_new)
        new_inds = [_make_evaluated_individual(x_new[i], f_new[i]) for i in range(n_new)]

        self.population = environmental_selection(elite + new_inds, self.pop_size, self.n_obj)
        self.mean_F = self.mean_CR = 0.5  # quên lịch sử thích nghi, tái học từ đầu

    def _fill_if_too_small(self, population: List[Individual]) -> List[Individual]:
        """Bổ sung cá thể ngẫu nhiên nếu remove_duplicates làm quần thể thiếu hụt."""
        missing = self.pop_size - len(population)
        if missing <= 0:
            return population

        x_fill = self.xl + np.random.rand(missing, self.n_var) * (self.xu - self.xl)
        f_fill = self.problem.evaluate(x_fill)
        extras = [_make_evaluated_individual(x_fill[i], f_fill[i]) for i in range(missing)]
        return population + extras

    # Cập nhật tham số thích nghi
    def _update_adaptive_parameters(
        self, offspring: List[Individual], *, reference_population: Optional[List[Individual]] = None
    ) -> None:
        """
        Cập nhật prob_de theo tỷ phần con DE được sinh; F/CR theo DE có rank 1.

        prob_de : success_rate (mặc định) hoặc fixed.
        success_rate chuẩn hóa tỷ lệ không bị trội theo số trial từng toán tử;
        giữ nguyên nếu thiếu toán tử hoặc cả hai không thành công.
        mean_F  : Lehmer mean của F — ưu giá trị lớn, khuyến khích khám phá
        mean_CR : trung bình cộng của CR

        F/CR success means nondominated in the evaluated parent/offspring pool
        BEFORE objective-space duplicate removal or crowding truncation. Each DE
        trial contributes once, including duplicate trials. Selection metadata
        may be missing/stale on discarded individuals and is not a success test.
        """
        if self.probability_update_mode not in {"success_rate", "fixed"}:
            raise ValueError("probability_update_mode must be success_rate or fixed")
        de_offspring  = [ind for ind in offspring if ind.creation_mode == CreationMode.DE]
        sbx_offspring = [ind for ind in offspring if ind.creation_mode == CreationMode.SBX]
        successful_de = []
        successful_sbx = []
        need_success = (self.enable_probability_adaptation and self.probability_update_mode == "success_rate")
        if (self.enable_fcr_adaptation and de_offspring) or need_success:
            pool = reference_population if reference_population is not None else self.population + offspring
            objectives = np.asarray([ind.F for ind in pool])
            for ind in de_offspring + (sbx_offspring if need_success else []):
                dominated = np.any(np.all(objectives <= ind.F, axis=1)
                                   & np.any(objectives < ind.F, axis=1))
                if not dominated:
                    (successful_de if ind.creation_mode == CreationMode.DE else successful_sbx).append(ind)

        total = len(de_offspring) + len(sbx_offspring)
        before = self.prob_de
        target = None
        if self.enable_probability_adaptation and total > 0:
            if self.probability_update_mode == "success_rate" and de_offspring and sbx_offspring:
                rate_de = len(successful_de) / len(de_offspring)
                rate_sbx = len(successful_sbx) / len(sbx_offspring)
                if rate_de + rate_sbx > 0:
                    target = rate_de / (rate_de + rate_sbx)
            if target is not None:
                self.prob_de = float(np.clip(0.9 * before + 0.1 * target, 0.2, 0.8))
        self.last_probability_update = {
            "mode": self.probability_update_mode, "enabled": self.enable_probability_adaptation,
            "n_de": len(de_offspring), "n_sbx": len(sbx_offspring),
            "success_de": len(successful_de) if need_success else None,
            "success_sbx": len(successful_sbx) if need_success else None,
            "target": target, "prob_before": before, "prob_after": self.prob_de}

        if self.enable_fcr_adaptation and successful_de:
            f_values     = np.array([ind.used_F  for ind in successful_de])
            cr_values    = np.array([ind.used_CR for ind in successful_de])
            lehmer_mean_F = float(np.mean(f_values ** 2) / np.mean(f_values))
            self.mean_F  = 0.9 * self.mean_F  + 0.1 * lehmer_mean_F
            self.mean_CR = 0.9 * self.mean_CR + 0.1 * float(np.mean(cr_values))
