"""Reusable figure quality checks."""
