"""Shared utility helpers."""

